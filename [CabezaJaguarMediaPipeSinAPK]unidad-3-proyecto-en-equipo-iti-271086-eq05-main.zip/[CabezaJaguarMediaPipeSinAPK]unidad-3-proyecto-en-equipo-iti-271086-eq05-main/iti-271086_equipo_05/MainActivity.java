// Definición del paquete de la aplicación
package upvictoria.pm_sep_sep_dic_2023.iti_271086.pg3u3_eq05;

// Importaciones de librerías necesarias
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import android.net.Uri;
import android.os.Bundle;
import android.widget.Toast;

// Importaciones del SDK de ARCore y Sceneform
import com.google.ar.core.AugmentedFace;
import com.google.ar.sceneform.ArSceneView;
import com.google.ar.sceneform.Sceneform;
import com.google.ar.sceneform.rendering.ModelRenderable;
import com.google.ar.sceneform.rendering.Renderable;
import com.google.ar.sceneform.rendering.RenderableInstance;
import com.google.ar.sceneform.rendering.Texture;
import com.google.ar.sceneform.ux.ArFrontFacingFragment;
import com.google.ar.sceneform.ux.AugmentedFaceNode;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.CompletableFuture;

// Clase principal de la aplicación
public class MainActivity extends AppCompatActivity {

    // Variables para gestionar la carga asíncrona de modelos y texturas
    private final Set<CompletableFuture<?>> loaders = new HashSet<>();

    // Fragmento y vista para AR
    private ArFrontFacingFragment arFragment;
    private ArSceneView arSceneView;

    // Textura y modelo para el rostro aumentado
    private Texture faceTexture;
    private ModelRenderable faceModel;

    // Mapa para rastrear los nodos de rostro aumentado
    private final HashMap<AugmentedFace, AugmentedFaceNode> facesNodes = new HashMap<>();

    // Método que se llama al crear la actividad
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Configura el layout de la actividad
        setContentView(R.layout.activity_main);

        // Agrega un oyente para el manejo de fragmentos
        getSupportFragmentManager().addFragmentOnAttachListener(this::onAttachFragment);

        // Inicializa el fragmento AR si es necesario
        if (savedInstanceState == null) {
            if (Sceneform.isSupported(this)) {
                getSupportFragmentManager().beginTransaction()
                        .add(R.id.arFragment, ArFrontFacingFragment.class, null)
                        .commit();
            }
        }

        // Carga los modelos y texturas
        loadModels();
        loadTextures();
    }

    // Maneja el evento de adjuntar un fragmento
    public void onAttachFragment(@NonNull FragmentManager fragmentManager, @NonNull Fragment fragment) {
        if (fragment.getId() == R.id.arFragment) {
            arFragment = (ArFrontFacingFragment) fragment;
            arFragment.setOnViewCreatedListener(this::onViewCreated);
        }
    }

    // Configura la vista AR cuando se crea
    public void onViewCreated(ArSceneView arSceneView) {
        this.arSceneView = arSceneView;

        // Establece la prioridad de renderizado para el flujo de la cámara
        arSceneView.setCameraStreamRenderPriority(Renderable.RENDER_PRIORITY_FIRST);

        // Configura un oyente para actualizaciones de rostros aumentados
        arFragment.setOnAugmentedFaceUpdateListener(this::onAugmentedFaceTrackingUpdate);
    }

    // Limpia los recursos al destruir la actividad
    @Override
    protected void onDestroy() {
        super.onDestroy();

        // Cancela operaciones asíncronas pendientes
        for (CompletableFuture<?> loader : loaders) {
            if (!loader.isDone()) {
                loader.cancel(true);
            }
        }
    }

    // Carga los modelos 3D de manera asíncrona
    private void loadModels() {
        loaders.add(ModelRenderable.builder()
                .setSource(this, Uri.parse("models/headcenter.glb"))
                .setIsFilamentGltf(true)
                .build()
                .thenAccept(model -> faceModel = model)
                .exceptionally(throwable -> {
                    Toast.makeText(this, "Unable to load renderable", Toast.LENGTH_LONG).show();
                    return null;
                }));
    }

    // Carga las texturas de manera asíncrona
    private void loadTextures() {
        loaders.add(Texture.builder()
                .setSource(this, Uri.parse("textures/freckles.png"))
                .setUsage(Texture.Usage.COLOR_MAP)
                .build()
                .thenAccept(texture -> faceTexture = texture)
                .exceptionally(throwable -> {
                    Toast.makeText(this, "Unable to load texture", Toast.LENGTH_LONG).show();
                    return null;
                }));
    }

    // Gestiona las actualizaciones en el seguimiento de rostros aumentados
    public void onAugmentedFaceTrackingUpdate(AugmentedFace augmentedFace) {
        // Retorna si los modelos o texturas no están cargados
        if (faceModel == null || faceTexture == null) {
            return;
        }

        // Obtiene el nodo de cara aumentada existente
        AugmentedFaceNode existingFaceNode = facesNodes.get(augmentedFace);

        // Gestiona el estado de seguimiento del rostro
        switch (augmentedFace.getTrackingState()) {
            case TRACKING:
                // Si no existe un nodo, lo crea y lo añade a la escena
                if (existingFaceNode == null) {
                    AugmentedFaceNode faceNode = new AugmentedFaceNode(augmentedFace);

                    RenderableInstance modelInstance = faceNode.setFaceRegionsRenderable(faceModel);
                    modelInstance.setShadowCaster(false);
                    modelInstance.setShadowReceiver(true);

                    faceNode.setFaceMeshTexture(faceTexture);

                    arSceneView.getScene().addChild(faceNode);

                    facesNodes.put(augmentedFace, faceNode);
                }
                break;
            case STOPPED:
                // Elimina el nodo si el seguimiento se detiene
                if (existingFaceNode != null) {
                    arSceneView.getScene().removeChild(existingFaceNode);
                }
                facesNodes.remove(augmentedFace);
                break;
        }
    }
}
