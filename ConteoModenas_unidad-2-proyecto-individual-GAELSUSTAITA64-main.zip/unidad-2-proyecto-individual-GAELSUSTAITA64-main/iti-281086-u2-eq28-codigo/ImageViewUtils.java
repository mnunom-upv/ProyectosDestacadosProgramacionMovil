package upvictoria.pm_sep_dic_2023.iti_271086.pi1u2.eq28;

import android.graphics.Bitmap;

import org.opencv.android.Utils;
import org.opencv.core.Mat;

public class ImageViewUtils {
    public static Bitmap matToBitmap(Mat inputImage) {
        Bitmap bitmap = Bitmap.createBitmap(inputImage.cols(), inputImage.rows(), Bitmap.Config.ARGB_8888);
        Utils.matToBitmap(inputImage, bitmap);
        return bitmap;
    }
}
