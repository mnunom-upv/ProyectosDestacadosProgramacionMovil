package upvictoria.pm_sep_dic_2023.iti_271086.pi1u2.eq28;

import static androidx.constraintlayout.helper.widget.MotionEffect.TAG;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import org.opencv.android.BaseLoaderCallback;
import org.opencv.android.LoaderCallbackInterface;
import org.opencv.android.OpenCVLoader;
import org.opencv.android.Utils;
import org.opencv.core.Mat;
import org.opencv.core.Point;
import org.opencv.core.Scalar;
import org.opencv.core.Size;
import org.opencv.imgproc.Imgproc;

import java.io.FileNotFoundException;
import java.io.InputStream;

public class MainActivity extends AppCompatActivity {

    private static final int PICK_IMAGE_REQUEST = 1;
    private ImageView imageCoins;

    private ImageView imageContorns;

    private TextView resultsTextView, resultTotal, indicaciones;
    private Button imagenSelect;

    private Mat originalImage;
    private int monedasDetectadas = 0;

    private RadioGroup coinsRadioGroup;
    private int monedaSeleccionada = 1;


    private BaseLoaderCallback loaderCallback = new BaseLoaderCallback(this) {
        @Override
        public void onManagerConnected(int status) {
            switch (status) {
                case LoaderCallbackInterface.SUCCESS:
                    // OpenCV initialization is successful
                    break;
                default:
                    super.onManagerConnected(status);
                    break;
            }
        }
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        if (OpenCVLoader.initDebug()) {
            Toast.makeText(getApplicationContext(),"OpenCV loaded"+OpenCVLoader.OPENCV_VERSION,Toast.LENGTH_SHORT).show();
        }
        imageCoins = findViewById(R.id.imageCoins);
        imageContorns = findViewById(R.id.contornosResult);
        imagenSelect = findViewById(R.id.imagenSelect);
        resultsTextView = findViewById(R.id.results);
        resultTotal = findViewById(R.id.resultTotal);
        indicaciones = findViewById(R.id.indicacionesText);
        coinsRadioGroup = findViewById(R.id.coinsSelect);
        coinsRadioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if (checkedId == R.id.moneda1) {
                    monedaSeleccionada = 1;
                } else if (checkedId == R.id.moneda2) {
                    monedaSeleccionada = 2;
                } else if (checkedId == R.id.moneda5) {
                    monedaSeleccionada = 5;
                } else if (checkedId == R.id.moneda10) {
                    monedaSeleccionada = 10;
                }
            }
        });


        imagenSelect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openImagePicker();
            }
        });
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);


    }
    private void openImagePicker() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, PICK_IMAGE_REQUEST);
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri selectedImageUri = data.getData();

            Log.d(TAG, "Selected Image URI: " + selectedImageUri);

            imageCoins.setImageURI(selectedImageUri);
            imageCoins.setVisibility(View.VISIBLE);
            imageContorns.setVisibility(View.VISIBLE);
            processImage(selectedImageUri);
        }
    }

    private void processImage(Uri imageUri) {
        monedasDetectadas = 0;

        Log.d(TAG, "Starting image processing...");

        // Cargar la imagen original usando BitmapFactory
        Bitmap bitmap = null;
        try {
            InputStream inputStream = getContentResolver().openInputStream(imageUri);
            bitmap = BitmapFactory.decodeStream(inputStream);
        } catch (FileNotFoundException e) {
            Log.e(TAG, "Error loading the original image: " + e.getMessage());
            return;
        }

        // Convertir el objeto Bitmap a una matriz Mat de OpenCV
        originalImage = new Mat();
        Utils.bitmapToMat(bitmap, originalImage);
        int newWidth1 = 0;
        int newHeight1 = 0;
        if (originalImage.cols() > originalImage.rows()){
            newWidth1 = 800;
            newHeight1 = 600;
        }else {
            newWidth1 = 600;
            newHeight1 = 800;
        }

        Mat resolutionImage = new Mat();
        Imgproc.resize(originalImage, resolutionImage, new Size(newWidth1, newHeight1));

        int newWidth = (int) (originalImage.cols() * 0.5);
        int newHeight = (int) (originalImage.rows() * 0.5);

        // Convertir la imagen original a escala de grises
        Log.d(TAG, "Converting to grayscale...");
        Mat grayImage = new Mat();
        Imgproc.cvtColor(resolutionImage, grayImage, Imgproc.COLOR_BGR2GRAY);

        // Aplicar el filtro de desenfoque gaussiano
        Log.d(TAG, "Applying Gaussian blur...");
        Mat blurredImage = new Mat();
        Imgproc.GaussianBlur(grayImage, blurredImage, new org.opencv.core.Size(7, 7), 0);

        // Aplicar el operador de Canny para detectar bordes
        Log.d(TAG, "Applying Canny edge detector...");
        Mat edgesImage = new Mat();
        Imgproc.Canny(blurredImage, edgesImage, 100, 200);

        // Aplicar el filtro de desenfoque gaussiano
        Log.d(TAG, "Applying Gaussian blur...");
        Mat blurredImage2 = new Mat();
        Imgproc.GaussianBlur(edgesImage, blurredImage2, new org.opencv.core.Size(7, 7), 2);

        // Detectar círculos usando la transformada de Hough
        Log.d(TAG, "Detecting circles using HoughCircles...");
        Mat circles = new Mat();
        Imgproc.HoughCircles(blurredImage2, circles, Imgproc.CV_HOUGH_GRADIENT, 1, 20, 30, 30, 48, 70);

        // Dibujar círculos en la imagen original
        Log.d(TAG, "Drawing circles...");
        for (int i = 0; i < circles.cols(); i++) {
            double[] circle = circles.get(0, i);
            if (circle != null) {
                Point center = new Point(Math.round(circle[0]), Math.round(circle[1]));
                int radius = (int) Math.round(circle[2]);
                // Dibujar el círculo en la imagen original
                Imgproc.circle(blurredImage2, center, radius, new Scalar(255, 0, 0), 2);
                monedasDetectadas++;
            }
        }


        resultsTextView.setText("La cantidad de monedas es de " + monedasDetectadas + " monedas");
        int cantidadTotal = monedaSeleccionada * monedasDetectadas;
        resultTotal.setText("La cantidad de dinero mostrada en la imagen es de " + cantidadTotal + " pesos");

        // Mostrar la imagen procesada en el ImageView
        Log.d(TAG, "Displaying processed image...");
        imageContorns.setImageBitmap(ImageViewUtils.matToBitmap(blurredImage2));
        imageCoins.setImageBitmap(ImageViewUtils.matToBitmap(originalImage));


        Log.d(TAG, "Image processing complete.");

        // Liberar el objeto Bitmap
        bitmap.recycle();
    }
}
